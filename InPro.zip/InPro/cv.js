% !TEX TS-program = latex
document.getElementById("cvForm").addEventListener("submit", function(event) {
    event.preventDefault();

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const phone = document.getElementById("phone").value;
    const linkedin = document.getElementById("linkedin").value;
    const objective = document.getElementById("objective").value;

    // Build LaTeX document string
    const latex = `
\\documentclass[a4paper,10pt]{article}
\\usepackage{parskip}
\\usepackage{geometry}
\\geometry{left=1in,right=1in,top=1in,bottom=1in}

\\begin{document}

\\begin{center}
    {\\Huge ${name}} \\\\
    \\vspace{0.1cm}
    ${email} | ${phone} | ${linkedin} \\\\
\\end{center}

\\section*{Objective}
${objective}

% Add more sections here for Work Experience, Education, Skills, etc.

\\end{document}
    `;

    // Display the generated LaTeX in the HTML page
    document.getElementById("latexOutput").textContent = latex;

    // Optional: send the LaTeX string to a backend server to compile it into a PDF
});
